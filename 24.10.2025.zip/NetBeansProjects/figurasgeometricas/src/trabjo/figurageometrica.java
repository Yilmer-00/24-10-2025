// esta es la clase principal de todas las figuras.
package trabjo;
//identificamos la clase 
public abstract class figurageometrica {
    //ponemos los metodos en private o privado 
    private final String nombre;
    //contructor para poner el nombre a figura.
    public figurageometrica(String nombre) {
        //nombramos  a nombre
        this.nombre = nombre;
    }
//el metodo nombre  para devolver
    public String getNombre() {
        return nombre;
    }
    
    public abstract double calcularArea();
    
    @Override
    public String toString() {
        return getNombre () + "- area :" + calcularArea();
    }
    
}
