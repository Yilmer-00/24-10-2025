//aqui es donde se ejecuta el programa
package trabjo;

import java.util.logging.Logger;

public class main {

    public static void main(String[] args) {
      
        figurageometrica c = new Circulo("circulo1", 3.0);
        
        figurageometrica r = new rectangulo("Rectangulo1", 4.0,2.5);
        
        figurageometrica t = new triangulo ("trinagulo1",5.0,3.0);
        
       figurageometrica[] figuras ={c, r, t};
       
       for (figurageometrica f : figuras){System.out.println(f.getNombre()+ "Area = " + f.calcularArea());
           
       } 
    } 
}
