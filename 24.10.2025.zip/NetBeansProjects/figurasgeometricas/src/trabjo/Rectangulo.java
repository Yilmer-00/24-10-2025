
package trabjo;

public class Rectangulo extends figurageometrica{
    //el rectangulo nesecita de la base y la altura
    private double base;
    private double altura;
    
    //ponemos el contructor donde mando nombre, base y altura

    public Rectangulo(double base, double altura, String nombre) {
        super(nombre);
        this.base = base;
        this.altura = altura;
    }
//formulamos como se calculara 
    public double calcularArea() {
        return base*altura;
    }
    
    
}
