//ahora la triangulo que tambien biene de figurageometrica
package trabjo;
//identifacomo lo metodos privados
public class Triangulo extends figurageometrica {
    private double base;
    private double altura;
    
    //el constructor para iniializar sus datos

    public Triangulo(double base, double altura, String nombre) {
        super(nombre);
        this.base = base;
        this.altura = altura;
    }
    //digitamos  la formula dela rea del triangulo
    public double calcularArea() {
        return (base*altura)/2.0;
    }    
}
