// la clase circulo, extiende de figurageometrica
package trabjo;

public abstract class circulo extends figurageometrica{
    //marcamos el metodo como privado e igual es nesesario para el circulo
    private final double radio;
// ingresamos el metodo contructor para el paso de nombre y el radio
    public circulo(double radio, String nombre) {
        //llamamos  al contructor de la clase padre.
        super(nombre);
        this.radio = radio;
    }

    
//aqui si programo como va hacer para calcular el area del circulo PI*radio^2
    public double calcularaArea() {
        return Math.PI* radio * radio;
    }
    
    
    
}
